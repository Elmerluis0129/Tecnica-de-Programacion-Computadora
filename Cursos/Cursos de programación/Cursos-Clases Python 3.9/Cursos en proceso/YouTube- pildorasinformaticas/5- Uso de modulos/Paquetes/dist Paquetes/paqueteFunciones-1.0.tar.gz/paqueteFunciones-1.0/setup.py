from setuptools import setup


setup (

	name = "paqueteFunciones",
	version = "1.0",
	description = "Paquete de Modulos, de las funciones matematias basicas",
	author = "Frozen Flame",
	author_email = "frozenflamepy@gmail.com",
	packages = ["Paquetes","Paquetes.Funciones"]


	)