from setuptools import setup


setup (

	name = "paqueteVehiculos",
	version = "1.0",
	description = "Paquete de Modulos, de mi proyecto Vehiculos",
	author = "Frozen Flame",
	author_email = "frozenflamepy@gmail.com",
	packages = ["Paquetes","Paquetes.Funciones"]


	)