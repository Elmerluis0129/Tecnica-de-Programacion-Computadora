def sumar(op1, op2):
	print(f"El resultado de la suma {op1} + {op2} es:\n> ", op1 + op2)

def restar(op1, op2):
	print(f"El resultado de la resta {op1} - {op2} es:\n> ", op1 - op2)

def dividir(op1, op2):
	print(f"El resultado de la divición {op1} / {op2} es:\n> ", op1 / op2)

def multiplicar(op1, op2):
	print(f"El resultado de la multiplicación {op1} * {op2} es:\n> ", op1 * op2)