from setuptools import setup


setup (

	name = "paquetecalculos",
	version = "1.0",
	description = "Paquete de funciones",
	author = "Danilo",
	author_email = "danilo@email.com",
	utl = "www.tupagina.com",
	packages = ["Funciones"]


	)