def sumar(op1, op2):
	print("El resultado de la suma es:\n> ", op1 + op2)

def restar(op1, op2):
	print("El resultado de la resta es:\n> ", op1 - op2)

def dividir(op1, op2):
	print("El resultado de la divición es:\n> ", op1 / op2)

def multiplicar(op1, op2):
	print("El resultado de la multiplicación es:\n> ", op1 * op2)